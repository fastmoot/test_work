<?php
require_once 'config.php';

if (!isset($_GET['id'])) {
    die("ID не указано.");
}

$id = $_GET['id'];

$query = "SELECT * FROM news WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$article = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$article) {
    die("Новость не найдена.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $short_description = $_POST['short_description'];
    $content = $_POST['content'];

    $updateQuery = "UPDATE news SET title = :title, short_description = :short_description, content = :content WHERE id = :id";
    $updateStmt = $pdo->prepare($updateQuery);
    $updateStmt->bindParam(':title', $title);
    $updateStmt->bindParam(':short_description', $short_description);
    $updateStmt->bindParam(':content', $content);
    $updateStmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($updateStmt->execute()) {
    header("Location: admin.php"); 
    exit;
	} else {
    echo "<div class='error'>Ошибка обновления новости.</div>";
	}

}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редагування новини</title>
	<link rel="stylesheet" href="style_edit.css">
</head>
<body>
    <div class="container">
        <h2>Редагування новини</h2>
        <?php if (isset($message)): ?>
            <div class="<?php echo $messageType; ?>"><?php echo $message; ?></div>
        <?php endif; ?>
        <form method="POST" action="edit.php?id=<?php echo $article['id']; ?>">
            <label for="title">Заголовок:</label>
            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($article['title']); ?>" required><br>

            <label for="short_description">Короткий опис:</label>
            <textarea id="short_description" name="short_description" rows="4" required><?php echo htmlspecialchars($article['short_description']); ?></textarea><br>

            <label for="content">Повний зміст:</label>
            <textarea id="content" name="content" rows="10" required><?php echo htmlspecialchars($article['content']); ?></textarea><br>

            <button type="submit">Зберегти зміни</button>
	</form><br>
    	<div class="links-container">
 	<span class="button"><a href="index.php">Повернутись до списку новин</a></span>      
        <span class="button"><a href="admin.php">Повернутись до адмінпанелі</a></span>
    </div>
	</div>
</body>
</html>
