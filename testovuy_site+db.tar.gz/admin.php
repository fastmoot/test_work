<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $short_description = $_POST['short_description'];
    $content = $_POST['content'];

    $maxTitleLength = 255;
    $maxShortDescriptionLength = 500;
    $maxContentLength = 5000;

    if (empty($title) || empty($short_description) || empty($content)) {
        $error = "Усі поля є обов'язковими!";
    }
    elseif (strlen($title) > $maxTitleLength) {
        $error = "Заголовок не може перевищувати $maxTitleLength символів!";
    } elseif (strlen($short_description) > $maxShortDescriptionLength) {
        $error = "Короткий опис не може перевищувати $maxShortDescriptionLength символів!";
    } elseif (strlen($content) > $maxContentLength) {
        $error = "Текст новини не може перевищувати $maxContentLength символів!";
    } else {
        $query = "INSERT INTO news (title, short_description, content) VALUES (:title, :short_description, :content)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':short_description', $short_description);
        $stmt->bindParam(':content', $content);

        if ($stmt->execute()) {
            $success = "Новину успішно додано!";
        } else {
            $error = "Помилка додавання новини!";
        }
    }
}

$itemsPerPage = 5;
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($currentPage - 1) * $itemsPerPage;

$totalQuery = "SELECT COUNT(*) AS total FROM news";
$totalStmt = $pdo->query($totalQuery);
$totalNews = $totalStmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPages = ceil($totalNews / $itemsPerPage);

$query = "SELECT * FROM news ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($query);
$stmt->bindValue(':limit', $itemsPerPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Адміністративна панель</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Адміністративна панель</h1>
    </header>

    <main>
        <h2>Додати новину</h2>
        <?php if (isset($error)): ?>
            <div class="error"><?= $error ?></div>
        <?php elseif (isset($success)): ?>
            <div class="success"><?= $success ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="title">Заголовок:</label>
            <input type="text" name="title" id="title" required>

            <label for="short_description">Короткий опис:</label>
            <textarea name="short_description" id="short_description" required></textarea>

            <label for="content">Текст новини:</label>
            <textarea name="content" id="content" required></textarea>

            <button type="submit">Додати новину</button>
        </form>

        <h2>Список новин</h2>
        <?php foreach ($news as $article): ?>
            <div class="news-item">
                <h3><?= htmlspecialchars($article['title']) ?></h3>
                <p><?= htmlspecialchars($article['short_description']) ?></p>
                <a href="edit.php?id=<?= $article['id'] ?>">Редагувати</a>
                <a href="delete.php?id=<?= $article['id'] ?>" onclick="return confirm('Ви впевнені, що хочете видалити цю новину?')">Видалити</a>
            </div>
        <?php endforeach; ?>

        <div class="pagination">
            <?php if ($currentPage > 1): ?>
                <a href="?page=<?= $currentPage - 1 ?>">&laquo; Попередня</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>" class="<?= $i == $currentPage ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
                <a href="?page=<?= $currentPage + 1 ?>">Наступна &raquo;</a>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>

