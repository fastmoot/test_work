<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM news WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $news_item = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$news_item) {
        die("Новину не знайдено.");
    }
} else {
    die("Не вказано ID новини.");
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($news_item['title']) ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1><?= htmlspecialchars($news_item['title']) ?></h1>
    </header>

    <main>
        <p><?= nl2br(htmlspecialchars($news_item['content'])) ?></p>
        <a href="index.php">Назад до списку новин</a>
    </main>
</body>
</html>
