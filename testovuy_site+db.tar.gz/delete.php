<?php
require_once 'config.php'; 

if (!isset($_GET['id'])) {
    die("ID новини не вказано.");
}

$id = $_GET['id'];

$query = "DELETE FROM news WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);

if ($stmt->execute()) {
    header("Location: admin.php");
    exit;
} else {
    die("Помилка видалення новини.");
}
?>

