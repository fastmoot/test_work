<?php
include 'config.php';

// Ініціалізація змінних
$filterDate = $_GET['date'] ?? ''; // Дата для фільтра
$searchQuery = $_GET['search'] ?? ''; // Ключове слово для пошуку
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Поточна сторінка
$itemsPerPage = 5; // Кількість новин на сторінку
$offset = ($currentPage - 1) * $itemsPerPage; // Відступ для SQL-запиту

// Запит для підрахунку загальної кількості новин
$countQuery = "SELECT COUNT(*) FROM news WHERE 1=1";
$params = [];
if (!empty($filterDate)) {
    $countQuery .= " AND DATE(created_at) = :filterDate";
    $params[':filterDate'] = $filterDate;
}
if (!empty($searchQuery)) {
    $countQuery .= " AND (title LIKE :search OR short_description LIKE :search)";
    $params[':search'] = '%' . $searchQuery . '%';
}
$countStmt = $pdo->prepare($countQuery);
$countStmt->execute($params);
$totalItems = $countStmt->fetchColumn();
$totalPages = ceil($totalItems / $itemsPerPage);

// Запит для вибірки новин з урахуванням фільтра, пошуку та пагінації
$query = "SELECT * FROM news WHERE 1=1";
if (!empty($filterDate)) {
    $query .= " AND DATE(created_at) = :filterDate";
}
if (!empty($searchQuery)) {
    $query .= " AND (title LIKE :search OR short_description LIKE :search)";
}
$query .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($query);
if (!empty($filterDate)) {
    $stmt->bindValue(':filterDate', $filterDate);
}
if (!empty($searchQuery)) {
    $stmt->bindValue(':search', '%' . $searchQuery . '%');
}
$stmt->bindValue(':limit', $itemsPerPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Головна сторінка</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Новини</h1>
    </header>

    <main>
        <!-- Фільтр за датою -->
        <form method="GET" action="">
            <label for="date">Фільтр за датою:</label>
            <input type="date" id="date" name="date" value="<?= htmlspecialchars($filterDate) ?>">
            
            <label for="search">Пошук:</label>
            <input type="text" id="search" name="search" placeholder="Введіть ключові слова" value="<?= htmlspecialchars($searchQuery) ?>">

            <button type="submit">Застосувати</button>
            <a href="/">Скинути фільтри</a>
        </form>

        <!-- Виведення новин -->
        <?php if (empty($news)): ?>
            <p>Новин не знайдено.</p>
        <?php else: ?>
            <?php foreach ($news as $article): ?>
                <div class="news-item">
                    <h2><?= htmlspecialchars($article['title']) ?></h2>
                    <p><strong>Дата публікації:</strong> <?= htmlspecialchars(date('Y-m-d', strtotime($article['created_at']))) ?></p>
                    <p><?= htmlspecialchars($article['short_description']) ?></p>
                    <a href="news.php?id=<?= $article['id'] ?>">Детальніше</a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Пагінація -->
        <div class="pagination">
            <?php if ($currentPage > 1): ?>
                <a href="?page=<?= $currentPage - 1 ?>&date=<?= htmlspecialchars($filterDate) ?>&search=<?= htmlspecialchars($searchQuery) ?>">&laquo; Попередня</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>&date=<?= htmlspecialchars($filterDate) ?>&search=<?= htmlspecialchars($searchQuery) ?>" class="<?= $i == $currentPage ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
                <a href="?page=<?= $currentPage + 1 ?>&date=<?= htmlspecialchars($filterDate) ?>&search=<?= htmlspecialchars($searchQuery) ?>">Наступна &raquo;</a>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>

