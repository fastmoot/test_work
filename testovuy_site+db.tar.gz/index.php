<?php
include 'config.php';

$filterDate = $_GET['date'] ?? ''; 
$searchQuery = $_GET['search'] ?? '';

$query = "SELECT * FROM news WHERE 1=1";

$params = [];
if (!empty($filterDate)) {
    $query .= " AND DATE(created_at) = :filterDate";
    $params[':filterDate'] = $filterDate;
}
if (!empty($searchQuery)) {
    $query .= " AND (title LIKE :search OR short_description LIKE :search)";
    $params[':search'] = '%' . $searchQuery . '%';
}
$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Головна сторінка</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Новини</h1>
    </header>

    <main>
        <!-- Фільтр за датою -->
        <form method="GET" action="">
            <label for="date">Фільтр за датою:</label>
            <input type="date" id="date" name="date" value="<?= htmlspecialchars($filterDate) ?>">
            
            <label for="search">Пошук:</label>
            <input type="text" id="search" name="search" placeholder="Введіть ключові слова" value="<?= htmlspecialchars($searchQuery) ?>">

            <button type="submit">Застосувати</button>
            <a href="/">Скинути фільтри</a>
        </form>

        <!-- Виведення новин -->
        <?php if (empty($news)): ?>
            <p>Новин не знайдено.</p>
        <?php else: ?>
            <?php foreach ($news as $article): ?>
                <div class="news-item">
                    <h2><?= htmlspecialchars($article['title']) ?></h2>
                    <p><strong>Дата публікації:</strong> <?= htmlspecialchars(date('Y-m-d', strtotime($article['created_at']))) ?></p>
                    <p><?= htmlspecialchars($article['short_description']) ?></p>
                    <a href="news.php?id=<?= $article['id'] ?>">Детальніше</a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </main>
</body>
</html>

